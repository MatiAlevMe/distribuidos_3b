# Data and Parameters

import numpy  as np
#
def load_config():
    ...
    return
# training data load
def load_dtrain():
    ...
    return
#matrix of weights and costs
def save_ws_costo():
    ...
    return
#load pretrained weights
def load_ws():
    ...
    return
#
